package com.ibm.magentotest;

import java.io.IOException;
import java.util.HashMap;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.ibm.magentopages.ForgotPasswordPage;
import com.ibm.magentopages.HomePage;
import com.ibm.magentopages.LoginPage;
import com.ibm.utilities.PropertiesFileHandler;


public class MagentoTest {

	public static void main(String[] args) throws IOException, InterruptedException  {
		
		String file="./TestData/magentodata.properties";
		
		//Location //Properties handler
		PropertiesFileHandler propFileHandler = new PropertiesFileHandler();
		HashMap<String, String> data= propFileHandler.getPropertiesAsMap(file);
		
		String url = data.get("url");
		String expectedMessage = data.get("expectedmessage");
		/*System.out.println(url);
		System.out.println(expectedMessage);*/
				
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		WebDriverWait wait = new WebDriverWait(driver, 60);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
		
		driver.get(url);
		
		HomePage home = new HomePage(driver);
		home.clickOnMyAccountIcon();
		
		LoginPage login = new LoginPage(driver);
		login.forgotpassword();
				
		String title=driver.getTitle();
		System.out.println("The title of Login page is: " +title);
		Thread.sleep(2000);
		
		ForgotPasswordPage fpwd = new ForgotPasswordPage(driver);
		fpwd.clickOnSubmitButton();
								
		String actualMessage = fpwd.getValidationMessage();		
				
		if(actualMessage.equals(expectedMessage))
		{
			System.out.println("Actual Message: "+actualMessage);
			System.out.println("The validation message is verified.");
		}
		else
		{
			System.out.println("The validation message is not as expected.");
		}
		
		System.out.println("End of program...");
	}

}