package com.ibm.magentopages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
//import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ForgotPasswordPage {
	
		By submitLoc = By.xpath("//button[@type='submit']");
		By messageLoc = By.xpath("//div[text()='This is a required field.']");
		//By emailLoc = By.xpath("//input[@id='email_address']");
	
		WebDriver driver;
		WebDriverWait wait;
				
		public ForgotPasswordPage(WebDriver driver)
		{
			this.driver=driver;
		}
		
		public void clickOnSubmitButton()
		{
			WebElement submitEle = driver.findElement(submitLoc);
			submitEle.click();
		}
		
		public String getValidationMessage()
		{
			WebElement messageEle = driver.findElement(messageLoc);
			String actualMessage = messageEle.getText();
			return actualMessage;
		}
		
		/*public void enterEmailAddress()
		{
			wait.until(ExpectedConditions.presenceOfElementLocated(messageLoc));
			WebElement emailEle = driver.findElement(emailLoc);
			emailEle.sendKeys("bala#$$");
		}*/
		
		
}
