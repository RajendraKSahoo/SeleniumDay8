package com.ibm.magentopages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.ibm.magentotest.MagentoTest;

public class HomePage {
	By myAccountIcon = By.xpath("//span[text()='Account']/ancestor::a");
	
WebDriver driver;
	
	public HomePage(WebDriver driver)
	{
		this.driver=driver;
	}
	
	public void clickOnMyAccountIcon()
	{
		WebElement myAccountEle = driver.findElement(myAccountIcon);
		myAccountEle.click();
	}
}