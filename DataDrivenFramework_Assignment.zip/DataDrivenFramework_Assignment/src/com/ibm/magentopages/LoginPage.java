package com.ibm.magentopages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class LoginPage {
	By fpwdLoc = By.xpath("//a[text()='Forgot Your Password?']");
		
	WebDriver driver;
	
	public LoginPage(WebDriver driver) {
		this.driver=driver;
	}
			
	public void forgotpassword()
	{
		WebElement forgotpwdEle = driver.findElement(fpwdLoc);
		forgotpwdEle.click();
	}
			
}
